// oss.c
// Author: Jerome Ramey, Jr.
// Date: May 15, 2025
// Description:
//   Operating System Simulator (OSS) for CS4760 Project 6. This module implements
//   a complete virtual memory simulation using SysV IPC and shared memory. It
//   handles the lifecycle of user processes, processes memory access requests,
//   detects page faults, queues disk I/O for page swaps, applies an LRU (Least
//   Recently Used) replacement policy, and maintains a shared clock to simulate
//   passage of time. Comprehensive logging is provided for debugging and analysis.
//
// Usage:
//   1. Build:
//        make
//   2. Run:
//        ./oss -n <total_procs> -s <max_simul> -i <interval_ms> -f <logfile>
//
//      - `-n <total_procs>`: Total number of user processes to spawn (1 to MAX_TOTAL_PROCS).
//      - `-s <max_simul>`:  Maximum concurrent processes allowed (1 to MAX_PROCS).
//      - `-i <interval_ms>`: Minimum simulated milliseconds between spawns.
//      - `-f <logfile>`:    Path to the file where all OSS events will be logged.
//
//   Upon start, OSS initializes the shared clock, message queue, frame table,
//   and page tables. It then enters a loop where it:
//     a) Advances the clock by MEM_ACCESS_TIME_NS for each simulated memory access.
//     b) Spawns new user processes when spawn interval and concurrency limits allow.
//     c) Receives memory access or termination requests from user processes.
//     d) On a page hit: immediately responds and updates LRU metadata.
//     e) On a page fault: selects a frame (free or LRU), evicts if necessary,
//        enqueues a disk I/O request, and logs the event.
//     f) Periodically services queued disk I/O when their simulated service time
//        has elapsed, installs pages, updates tables, notifies the waiting process,
//        and logs the completion.
//     g) Prints the entire frame table and all occupied page tables once per
//        simulated second for visibility.
//     h) Reaps terminated children without blocking.
//   The loop continues until all processes have terminated and no disk requests remain.
//   Clean shutdown is invoked on normal completion or upon receiving SIGINT/SIGALRM,
//   ensuring all IPC resources and shared memory are properly released.
//
//   Refer to the Makefile for compilation flags and dependencies.
//
// ----------------------------------------------------------------------------

#define _POSIX_C_SOURCE 200809L
#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <signal.h>
#include <stdbool.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "ipc.h"           // IPC constants, message structs for request/response
#include "oss.h"           // PCB and global configuration constants
#include "clock.h"         // Shared clock management functions
#include "utils.h"         // Logging, random address/op generation, table printing
#include "frame_table.h"   // Frame table init, LRU selection, eviction
#include "page_table.h"    // Per-process page table ops (set, invalidate)

//-----------------------------------------------------------------------------
// Data structure for enqueued disk requests (page swaps)
//
// Each disk_request_t represents a pending page-in for a faulted access.
// It records the requesting process, page number, chosen frame, whether the
// swap is dirty (write-back needed), and the timestamp when enqueued.
// These requests form a FIFO queue and are serviced when simulated time
// exceeds the required disk latency (clean vs. dirty).
//-----------------------------------------------------------------------------

typedef struct disk_request {
    pid_t pid;                 // PID of user process needing the page
    int page_num;              // Virtual page index to load
    int frame_no;              // Physical frame assigned for swap-in
    bool is_dirty;             // True if write-back latency applies
    uint32_t req_sec;          // Shared clock seconds at enqueue time
    uint32_t req_ns;           // Shared clock nanoseconds at enqueue time
    struct disk_request *next; // Pointer to next request in FIFO queue
} disk_request_t;

//-----------------------------------------------------------------------------
// Global simulation state
//-----------------------------------------------------------------------------

static pcb_t pcbs[MAX_PROCS];                   // Array of process control blocks
static frame_t frames[FRAME_TABLE_SIZE];        // Physical memory frame descriptors
static disk_request_t *disk_head = NULL;        // Head of disk request queue
static disk_request_t *disk_tail = NULL;        // Tail of disk request queue
static int msqid = -1;                          // SysV message queue ID
static int clock_shmid = -1;                    // Shared memory ID for clock
static int total_spawned = 0;                   // Cumulative processes spawned
static int current_children = 0;                // Currently active user processes
static uint32_t last_spawn_sec = 0;             // Last spawn time seconds
static uint32_t last_spawn_ns = 0;              // Last spawn time nanoseconds
static uint32_t spawn_interval_ns = 0;          // Nanoseconds between spawns threshold
static bool running = true;                     // Main loop control flag

// Forward declaration of cleanup to allow its use in signal handler
void cleanup(void);

//-----------------------------------------------------------------------------
// Signal handler
//
// Catches SIGINT (Ctrl-C) and SIGALRM (real-time timeout) to trigger
// an orderly shutdown via cleanup(). Logs the signal before cleanup.
//-----------------------------------------------------------------------------

void sig_handler(int sig) {
    log_event("Signal %d received, initiating cleanup.", sig);
    cleanup();
}

//-----------------------------------------------------------------------------
// cleanup
//
// Performs a thorough shutdown of the simulation by:
//   - Setting running = false to stop loops
//   - Killing all active user processes via SIGTERM
//   - Reaping all child processes to avoid zombies
//   - Removing the SysV message queue
//   - Marking the shared clock segment for removal
//   - Freeing all pending disk_request_t nodes
//   - Detaching and removing the shared clock
//   - Closing the log file
//   - Exiting the program successfully
//
// This ensures no shared memory or IPC resources remain allocated.
//-----------------------------------------------------------------------------

void cleanup(void) {
    running = false;

    // Terminate user processes
    for (int i = 0; i < MAX_PROCS; ++i) {
        if (pcbs[i].occupied) {
            kill(pcbs[i].pid, SIGTERM);
        }
    }
    // Reap any remaining child processes
    while (waitpid(-1, NULL, 0) > 0) {}

    // Remove message queue
    if (msqid != -1) {
        msgctl(msqid, IPC_RMID, NULL);
    }
    // Remove shared clock memory
    if (clock_shmid != -1) {
        shmctl(clock_shmid, IPC_RMID, NULL);
    }
    // Free disk request queue
    disk_request_t *cur = disk_head;
    while (cur) {
        disk_request_t *next = cur->next;
        free(cur);
        cur = next;
    }
    disk_head = disk_tail = NULL;

    // Detach and destroy shared clock
    detach_clock();
    destroy_clock();

    // Close log file
    close_logging();

    exit(EXIT_SUCCESS);
}

//-----------------------------------------------------------------------------
// enqueue_request
//
// Appends a new disk_request_t to the end of the disk_head/tail queue.
// Ensures FIFO ordering for page-in requests.
// @param req Pointer to the newly allocated disk_request_t node.
//-----------------------------------------------------------------------------

void enqueue_request(disk_request_t *req) {
    if (!disk_head) {
        disk_head = disk_tail = req;
    } else {
        disk_tail->next = req;
        disk_tail = req;
    }
    req->next = NULL;
}

//-----------------------------------------------------------------------------
// process_disk_queue
//
// Checks the head of the disk request queue against the shared clock to
// determine if the required disk latency (CLEAN_SWAP_TIME_NS or
// DIRTY_SWAP_TIME_NS) has elapsed. If so, it:
//   - Install the page into the assigned frame
//   - Update frame metadata (occupied, dirty, pid, page_number, timestamp)
//   - Update the corresponding process's page table mapping
//   - Send an IPC response message to the waiting user process
//   - Log the completion event
//   - Remove the request node from the queue and free its memory
//-----------------------------------------------------------------------------

void process_disk_queue(void) {
    if (!disk_head) {
        return;  // No queued requests
    }

    uint32_t cur_sec, cur_ns;
    get_clock(&cur_sec, &cur_ns);

    // Calculate elapsed time since the head was enqueued
    uint64_t elapsed_ns = (uint64_t)(cur_sec - disk_head->req_sec) * 1000000000UL
                        + (cur_ns - disk_head->req_ns);

    // Determine required service time based on dirty flag
    uint32_t needed = disk_head->is_dirty ? DIRTY_SWAP_TIME_NS : CLEAN_SWAP_TIME_NS;

    if (elapsed_ns >= needed) {
        // Service the request
        disk_request_t *req = disk_head;

        // Populate frame descriptor
        frames[req->frame_no].occupied    = true;
        frames[req->frame_no].dirty       = req->is_dirty;
        frames[req->frame_no].pid         = req->pid;
        frames[req->frame_no].page_number = req->page_num;
        update_frame_reference(frames, req->frame_no, req->is_dirty);

        // Update process's page table
        for (int i = 0; i < MAX_PROCS; ++i) {
            if (pcbs[i].occupied && pcbs[i].pid == req->pid) {
                set_page_frame(pcbs[i].page_table, req->page_num, req->frame_no);
                break;
            }
        }

        // Notify user process that page-in is complete
        response_msg_t resp = {
            req->pid,
            req->frame_no,
            req->is_dirty ? OP_WRITE : OP_READ
        };
        msgsnd(msqid, &resp, sizeof(resp) - sizeof(long), 0);

        // Log completion with timestamp
        log_event("oss: Completed swap for P%d page %d into frame %d at %u:%u",
                  req->pid, req->page_num, req->frame_no, cur_sec, cur_ns);

        // Dequeue the request
        disk_head = req->next;
        if (!disk_head) {
            disk_tail = NULL;
        }
        free(req);
    }
}

//-----------------------------------------------------------------------------
// main
//
// Entry point for OSS. Orchestrates setup, simulation loop, and teardown.
// Steps:
//   1. Parse command-line options (-n, -s, -i, -f, -h).
//   2. Install signal handlers for SIGINT and SIGALRM (5s timeout).
//   3. Initialize logging, shared clock, frame & page tables, random seed.
//   4. Create or attach IPC message queue.
//   5. Loop until all processes are spawned & terminated and no disk requests remain:
//        a) increment_clock by MEM_ACCESS_TIME_NS
//        b) maybe spawn a new user process (fork+exec) if interval & limit allow
//        c) msgrcv nonblocking to handle incoming request_msg_t:
//             - On OP_TERMINATE: log, free frames, mark PCB free.
//             - On OP_READ/WRITE: compute page, check hit/fault.
//               * Hit: update LRU, respond immediately.
//               * Fault: select free or LRU frame, evict if needed,
//                        create & enqueue disk_request_t, log fault.
//        d) process_disk_queue() to service ready page-in requests.
//        e) once per simulated second: print frame and page tables.
//        f) reap any terminated children with waitpid(WNOHANG).
//   6. Upon loop exit or signal: cleanup() and exit.
//
// Returns 0 on normal completion.
//-----------------------------------------------------------------------------

int main(int argc, char *argv[]) {
    int n = 0;               // Total processes to spawn via -n
    int s = 0;               // Max simultaneous processes via -s
    char *logfile = NULL;    // Log file path via -f
    spawn_interval_ns = 1000000UL; // Default 1ms between spawns
    int opt;

    // Parse CLI options
    while ((opt = getopt(argc, argv, "hn:s:i:f:")) != -1) {
        switch (opt) {
            case 'h':
                printf("Usage: %s -n <total_procs> -s <max_simul> -i <interval_ms> -f <logfile>\n", argv[0]);
                return 0;
            case 'n': n = atoi(optarg); break;
            case 's': s = atoi(optarg); if (s > MAX_PROCS) s = MAX_PROCS; break;
            case 'i': spawn_interval_ns = (uint32_t)atoi(optarg) * 1000000UL; break;
            case 'f': logfile = optarg; break;
        }
    }
    if (!n || !s || !logfile) {
        fprintf(stderr, "Missing required arguments\n");
        cleanup();
    }

    // Set up clean shutdown on signals
    signal(SIGINT, sig_handler);
    signal(SIGALRM, sig_handler);
    alarm(5);  // Auto-terminate after 5 real seconds

    // Initialize logging
    init_logging(logfile);

    // Initialize and attach shared clock
    if (init_clock() == -1) cleanup();
    key_t shmkey = ftok(".", 'C');
    clock_shmid = shmget(shmkey, sizeof(shm_clock_t), IPC_CREAT | 0666);
    attach_clock_segment(clock_shmid);

    // Initialize memory management tables
    init_frame_table(frames);
    for (int i = 0; i < MAX_PROCS; ++i) {
        init_page_table(pcbs[i].page_table);
        pcbs[i].occupied = false;
    }

    // Seed random generator for user processes
    init_random();

    // Create IPC message queue for requests/responses
    key_t key = ftok(IPC_KEY_FILEPATH, IPC_KEY_PROJ_ID);
    msqid = msgget(key, IPC_CREAT | 0666);

    uint32_t cur_sec = 0, cur_ns = 0;

    // Main simulation loop
    while (running && (total_spawned < n || current_children > 0 || disk_head)) {
        // a) Simulate memory access delay
        increment_clock(0, MEM_ACCESS_TIME_NS);
        get_clock(&cur_sec, &cur_ns);

        // b) Spawn new process if interval & concurrency constraints allow
        uint64_t spawn_elapsed_ns = (uint64_t)(cur_sec - last_spawn_sec) * 1000000000UL
                                  + (cur_ns - last_spawn_ns);
        if (total_spawned < n && current_children < s && spawn_elapsed_ns >= spawn_interval_ns) {
            int idx;
            for (idx = 0; idx < MAX_PROCS; ++idx) {
                if (!pcbs[idx].occupied) break;
            }
            pid_t pid = fork();
            if (pid == 0) {
                // Child: exec the user process binary
                execl("./user_proc", "user_proc", NULL);
                perror("execl");
                exit(EXIT_FAILURE);
            } else if (pid > 0) {
                // Parent: record PCB entry
                pcbs[idx].occupied  = true;
                pcbs[idx].pid       = pid;
                pcbs[idx].start_sec = cur_sec;
                pcbs[idx].start_ns  = cur_ns;
                total_spawned++;
                current_children++;
                last_spawn_sec = cur_sec;
                last_spawn_ns  = cur_ns;
                log_event("oss: Launched P%d at %u:%u", pid, cur_sec, cur_ns);
            } else {
                perror("fork");
            }
        }

        // c) Handle incoming messages (non-blocking)
        request_msg_t req;
        while (msgrcv(msqid, &req, sizeof(req) - sizeof(long), MSG_TYPE_REQUEST, IPC_NOWAIT) != -1) {
            int idx = -1;
            for (int i = 0; i < MAX_PROCS; ++i) {
                if (pcbs[i].occupied && pcbs[i].pid == req.pid) {
                    idx = i;
                    break;
                }
            }

            // Termination request from user_proc
            if (req.operation == OP_TERMINATE) {
                get_clock(&cur_sec, &cur_ns);
                log_event("oss: P%d terminating at %u:%u, runtime %u:%u",
                          req.pid, cur_sec, cur_ns,
                          cur_sec - pcbs[idx].start_sec,
                          cur_ns  - pcbs[idx].start_ns);
                free_frames_by_pid(frames, req.pid);
                pcbs[idx].occupied = false;
                current_children--;
                continue;
            }

            // Compute page index from address
            int page_num = req.address / PAGE_SIZE;
            int frame_no = get_frame_for_page(pcbs[idx].page_table, page_num);

            if (frame_no != -1) {
                // Page hit: update LRU and respond immediately
                update_frame_reference(frames, frame_no, req.operation == OP_WRITE);
                response_msg_t resp = { req.pid, frame_no, req.operation };
                msgsnd(msqid, &resp, sizeof(resp) - sizeof(long), 0);
                log_event("oss: P%d %s hit page %d in frame %d at %u:%u",
                          req.pid,
                          req.operation == OP_WRITE ? "write" : "read",
                          page_num, frame_no, cur_sec, cur_ns);
            } else {
                // Page fault: select a frame (free or LRU), evict if needed
                int free_frame = find_free_frame(frames);
                int use_frame  = (free_frame != -1) ? free_frame : select_lru_frame(frames);
                if (free_frame == -1) {
                    // Eviction: invalidate old mapping in its owner’s page table
                    int old_pid  = frames[use_frame].pid;
                    int old_page = frames[use_frame].page_number;
                    for (int i = 0; i < MAX_PROCS; ++i) {
                        if (pcbs[i].occupied && pcbs[i].pid == old_pid) {
                            invalidate_page(pcbs[i].page_table, old_page);
                            break;
                        }
                    }
                    clear_frame(frames, use_frame);
                }
                // Enqueue disk I/O for this page-in
                disk_request_t *dr = malloc(sizeof(*dr));
                dr->pid       = req.pid;
                dr->page_num  = page_num;
                dr->frame_no  = use_frame;
                dr->is_dirty  = (req.operation == OP_WRITE);
                dr->req_sec   = cur_sec;
                dr->req_ns    = cur_ns;
                dr->next      = NULL;
                enqueue_request(dr);
                log_event("oss: Page fault P%d page %d queued for frame %d at %u:%u",
                          req.pid, page_num, use_frame, cur_sec, cur_ns);
            }
        }

        // d) Service any ready disk requests
        process_disk_queue();

        // e) Once per simulated second: dump tables
        static uint32_t last_output_sec = 0;
        if (cur_sec != last_output_sec) {
            print_frame_table(frames, FRAME_TABLE_SIZE);
            print_page_tables(pcbs, MAX_PROCS);
            last_output_sec = cur_sec;
        }

        // f) Reap terminated children non-blocking
        while (waitpid(-1, NULL, WNOHANG) > 0) {}
    }

    // Graceful shutdown
    cleanup();
    return 0;
}
