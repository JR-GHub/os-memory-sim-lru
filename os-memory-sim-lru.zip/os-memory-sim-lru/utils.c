// utils.c
// Author: Jerome Ramey, Jr.
// Date: May 15, 2025
//
// Description:
//   Utility module for the CS4760 Project 6 virtual memory simulator.
//   Provides functions for:
//     - Initializing and closing the logging facility (both to file and stdout).
//     - Seeding the pseudo-random generator uniquely per process.
//     - Generating randomized memory addresses and operations.
//     - Logging events uniformly to both log file and console.
//     - Pretty-printing the frame table and page tables for debugging.
//
// Usage:
//   1. Call init_logging("<path/to/logfile>") early in OSS to open the log.
//   2. Use log_event() to record timestamped messages to both log and stdout.
//   3. Call init_random() in each process to seed its RNG uniquely.
//   4. Generate addresses with generate_address() and operations with generate_operation().
//   5. After simulation, call close_logging() to flush and close the log file.
//   6. To inspect memory structures, call print_frame_table() and print_page_tables().
//
// The module assumes the following constants are defined in included headers:
//   PAGE_SIZE, PAGE_TABLE_SIZE, IPC_KEY_FILEPATH, IPC_KEY_PROJ_ID, OP_READ, OP_WRITE
//   frame_t (structure for frame-table entries), pcb_t (process control block).

#include "utils.h"
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

// Global file pointer for writing log entries.
// After init_logging(), log_fp is non-NULL until close_logging().
FILE *log_fp = NULL;

/**
 * init_logging
 * ------------
 * Open the specified file for writing all subsequent log entries.
 * If the file cannot be opened, prints an error and terminates.
 *
 * @param filename  Path to the log file (overwrites existing content).
 */
void init_logging(const char *filename) {
    log_fp = fopen(filename, "w");
    if (!log_fp) {
        perror("fopen log file");  // Log file creation/opening failed
        exit(EXIT_FAILURE);
    }
}

/**
 * close_logging
 * -------------
 * Flushes and closes the log file if it is open.
 * After this call, log_fp is set to NULL and no further logging will occur.
 */
void close_logging(void) {
    if (log_fp) {
        fclose(log_fp);
        log_fp = NULL;
    }
}

/**
 * init_random
 * -----------
 * Seed the process-local pseudo-random number generator using
 * a combination of the current time and the process ID.
 * Ensures different sequences across forks/users.
 */
void init_random(void) {
    // XOR time with PID provides high entropy per-process seed
    srand((unsigned)time(NULL) ^ getpid());
}

/**
 * generate_address
 * ----------------
 * Create a uniformly random 32-bit memory address within the
 * virtual address space of one process.
 * The process has PAGE_TABLE_SIZE pages, each PAGE_SIZE bytes.
 *
 * @return Random address = page_index * PAGE_SIZE + page_offset
 */
uint32_t generate_address(void) {
    int page   = rand() % PAGE_TABLE_SIZE;  // Select virtual page [0, PAGE_TABLE_SIZE)
    int offset = rand() % PAGE_SIZE;        // Select offset within page [0, PAGE_SIZE)
    return (uint32_t)(page * PAGE_SIZE + offset);
}

/**
 * generate_operation
 * ------------------
 * Randomly choose between read (80% probability) and write (20%).
 *
 * @return OP_READ or OP_WRITE
 */
int generate_operation(void) {
    return (rand() % 100) < 80 ? OP_READ : OP_WRITE;
}

/**
 * log_event
 * ---------
 * Emit a formatted log message to both the log file (if open) and stdout.
 * Prepends no timestamp; OSS itself advances the simulated clock and logs
 * timestamps if desired in the fmt string.
 *
 * @param fmt  printf-style format string for the event.
 * @param ...  corresponding variable arguments.
 */
void log_event(const char *fmt, ...) {
    va_list args;
    va_start(args, fmt);

    // Write to log file first
    if (log_fp) {
        vfprintf(log_fp, fmt, args);
        fprintf(log_fp, "\n");
        fflush(log_fp);
    }

    // Then echo to console for real-time monitoring
    vprintf(fmt, args);
    printf("\n");

    va_end(args);
}

/**
 * print_frame_table
 * -----------------
 * Output the current contents of the physical frame table.
 * For each frame, logs:
 *   - Frame index
 *   - Occupied status (Yes/No)
 *   - Dirty bit
 *   - Owning PID (if any)
 *   - Loaded page number
 *   - Last reference timestamp (sec:ns)
 *
 * @param frames  Array of frame_t entries representing physical memory.
 * @param size    Number of frames in the table (FRAME_TABLE_SIZE).
 */
void print_frame_table(frame_t frames[], int size) {
    log_event("Frame Table:");
    for (int i = 0; i < size; ++i) {
        log_event("  Frame %3d | Occupied=%-3s | Dirty=%d | PID=%5d | Page=%3d | LastRef=%u:%u",
                  i,
                  frames[i].occupied ? "Yes" : "No",
                  frames[i].dirty,
                  frames[i].pid,
                  frames[i].page_number,
                  frames[i].last_ref_sec,
                  frames[i].last_ref_ns);
    }
}

/**
 * print_page_tables
 * -----------------
 * Output the page tables for all active processes.
 * Iterates through the PCB array; for each occupied slot, logs:
 *   - Process PID
 *   - Page → frame mapping for PAGE_TABLE_SIZE entries
 *
 * @param pcbs       Array of pcb_t entries (size MAX_PROCS).
 * @param max_procs  Maximum number of PCBs in the system.
 */
void print_page_tables(pcb_t pcbs[], int max_procs) {
    log_event("Process Page Tables:");
    for (int i = 0; i < max_procs; ++i) {
        if (!pcbs[i].occupied) continue;

        // Header with PID
        log_event("  P%ld: [", (long)pcbs[i].pid);

        // Inline mapping list: frame number or -1
        printf("    ");
        for (int j = 0; j < PAGE_TABLE_SIZE; ++j) {
            printf("%3d", pcbs[i].page_table[j]);
            if (j < PAGE_TABLE_SIZE - 1) {
                printf(" ");
            }
        }
        printf("  ]\n");
    }
}
