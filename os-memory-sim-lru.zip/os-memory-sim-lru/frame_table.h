// frame_table.h
// Author: Jerome Ramey, Jr.
// Date: May 15, 2025
//
// Description:
//   This header defines the interface for managing the physical memory frame table
//   in the CS4760 Project 6 virtual memory simulation. The frame table represents
//   the simulated RAM of the system and tracks the state of each frame, including
//   whether it is occupied, whether it has been written to (dirty bit), which process
//   and page it belongs to, and when it was last accessed.
//
//   The core responsibilities exposed through this interface include:
//   - Initializing the frame table
//   - Locating free frames or selecting victims for replacement (LRU policy)
//   - Updating frame access metadata
//   - Clearing or reclaiming frames when processes terminate
//
// Usage:
//   The functions in this header are implemented in `frame_table.c` and used primarily
//   by `oss.c` (the operating system simulator).
//
//   Example flow in OSS:
//     - At initialization: call `init_frame_table()` to prepare all frames.
//     - When servicing a memory access request:
//         1. Use `find_free_frame()` to check for available space.
//         2. If no free frame is found, use `select_lru_frame()` to choose an eviction candidate.
//         3. Update frame metadata (last access time and dirty bit) using `update_frame_reference()`.
//     - When replacing a page or terminating a process:
//         - Use `clear_frame()` to free a specific frame.
//         - Use `free_frames_by_pid()` to release all frames belonging to a process.
//
//   This interface allows efficient frame management, enabling paging and memory replacement
//   strategies to be correctly simulated in the OSS memory system.

#ifndef FRAME_TABLE_H
#define FRAME_TABLE_H

#include <stdbool.h>
#include <sys/types.h>
#include "oss.h"

// Initializes all entries in the frame table to default unused values.
// Resets metadata such as occupied, dirty, PID, page number, and timestamps.
//
// @param frames Array of frame_t structures representing physical memory frames.
void init_frame_table(frame_t frames[]);

// Searches the frame table for the first unoccupied frame.
// Typically used before needing to evict a page.
//
// @param frames Array of frame_t structures.
// @return Index of the first free frame, or -1 if no free frame is found.
int find_free_frame(frame_t frames[]);

// Applies Least Recently Used (LRU) replacement algorithm to select a victim frame.
// Compares timestamps of last reference to find the oldest used frame.
//
// @param frames Array of frame_t structures.
// @return Index of the selected LRU frame, or -1 if no frame is currently occupied.
int select_lru_frame(frame_t frames[]);

// Updates the access timestamp and dirty bit for the specified frame.
// Should be called after every access (read/write) to the frame.
//
// @param frames Array of frame_t structures.
// @param frame_no Index of the frame being accessed.
// @param is_write Boolean indicating whether the access was a write (true) or read (false).
void update_frame_reference(frame_t frames[], int frame_no, bool is_write);

// Clears the metadata of a single frame, marking it as unoccupied and resetting ownership.
//
// @param frames Array of frame_t structures.
// @param frame_no Index of the frame to be cleared.
void clear_frame(frame_t frames[], int frame_no);

// Frees all frames that are owned by the specified process.
// Should be called upon process termination to release its memory.
//
// @param frames Array of frame_t structures.
// @param pid Process ID whose associated frames should be released.
void free_frames_by_pid(frame_t frames[], pid_t pid);

#endif // FRAME_TABLE_H
