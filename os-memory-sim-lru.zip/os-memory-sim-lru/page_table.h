// page_table.h
// Author: Jerome Ramey, Jr.
// Date: May 15, 2025
// Description:
//   Defines the interface for managing per-process page tables in the CS4760
//   Project 6 Operating System Simulator. Each user process maintains a fixed‐size
//   page table of PAGE_TABLE_SIZE entries, mapping virtual page numbers to physical
//   frame numbers. A value of -1 indicates that the page is not currently loaded
//   into any frame (i.e., a page fault will occur when accessed).
//
// Usage:
//   1. Include this header in any module that manipulates page tables.
//   2. On process creation or PCB initialization, call init_page_table() to set
//      all entries to -1.
//   3. When handling a page fault, use set_page_frame() to record the frame into
//      which the virtual page has been loaded.
//   4. To check if a virtual page is resident, call get_frame_for_page(); if it
//      returns -1, the page must be loaded first.
//   5. When evicting a page (on LRU replacement or process termination), call
//      invalidate_page() for the specific page number to mark it invalid.
//   6. To reset an entire page table (e.g., on process recycle), call
//      clear_page_table(), which reinitializes every entry to -1.
//   7. All functions perform bounds checking on page indices to protect against
//      invalid accesses.
//
// Example:
//     int pt[PAGE_TABLE_SIZE];
//     init_page_table(pt);                         // Step 2: initialize
//     int frame = find_free_frame(frames);         // from frame_table.c
//     set_page_frame(pt, virtual_page, frame);     // Step 3: map page → frame
//     int fno = get_frame_for_page(pt, virtual_page);
//     if (fno < 0) { /* handle page fault */ }
//     invalidate_page(pt, virtual_page);           // Step 5: unmap single page
//     clear_page_table(pt);                        // Step 6: reset all mappings

#ifndef PAGE_TABLE_H
#define PAGE_TABLE_H

#include "oss.h"

/**
 * init_page_table
 * ----------------
 * Initialize a page table by marking all PAGE_TABLE_SIZE entries as not resident.
 *
 * @param page_table   Array of int of length PAGE_TABLE_SIZE representing
 *                     the process's page table.
 *                     After this call, every entry is set to -1.
 */
void init_page_table(int page_table[]);

/**
 * get_frame_for_page
 * ------------------
 * Look up which physical frame a given virtual page is mapped to.
 *
 * @param page_table   The process's page table array.
 * @param page_num     Virtual page index to query (0 <= page_num < PAGE_TABLE_SIZE).
 * @return             The frame number (0 <= frame < FRAME_TABLE_SIZE) if the page
 *                     is loaded; -1 if the page is not resident or page_num is invalid.
 */
int get_frame_for_page(int page_table[], int page_num);

/**
 * set_page_frame
 * --------------
 * Record that a virtual page has been loaded into a specific physical frame.
 *
 * @param page_table   The process's page table array.
 * @param page_num     Virtual page index to map (0 <= page_num < PAGE_TABLE_SIZE).
 * @param frame_no     Physical frame number to assign (0 <= frame_no < FRAME_TABLE_SIZE).
 *                     Sets page_table[page_num] = frame_no.
 */
void set_page_frame(int page_table[], int page_num, int frame_no);

/**
 * invalidate_page
 * ---------------
 * Unmap (invalidate) a single virtual page, marking it as not resident.
 *
 * @param page_table   The process's page table array.
 * @param page_num     Virtual page index to invalidate (0 <= page_num < PAGE_TABLE_SIZE).
 *                     After this call, page_table[page_num] = -1.
 */
void invalidate_page(int page_table[], int page_num);

/**
 * clear_page_table
 * ----------------
 * Reset all entries in the page table to -1, effectively unloading all pages.
 *
 * @param page_table   The process's page table array.
 *                     After this call, every entry is -1.
 */
void clear_page_table(int page_table[]);

#endif // PAGE_TABLE_H
