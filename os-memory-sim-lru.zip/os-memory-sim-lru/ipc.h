// ipc.h  
// Author: Jerome Ramey, Jr.  
// Date: May 15, 2025  
//
// Description:  
//   This header file defines the constants and message structures used for  
//   inter-process communication (IPC) between the `oss` program (Operating System  
//   Simulator) and its child processes (`user_proc`) in CS4760 Project 6.  
//   Communication is conducted through a System V message queue.  
//   The `request_msg_t` struct encapsulates memory access requests from user processes,  
//   while the `response_msg_t` struct represents the OSS's response to those requests.
//
// Usage:  
//   - Both oss.c and user_proc.c include this file to communicate via message queues.  
//   - The `ftok()` function uses `IPC_KEY_FILEPATH` and `IPC_KEY_PROJ_ID` to generate  
//     a consistent message queue key for both sender and receiver.  
//   - `user_proc` sends `request_msg_t` messages with `mtype = MSG_TYPE_REQUEST`.  
//   - `oss` responds using `response_msg_t`, with `mtype = PID` of the target process.  
//   - The `operation` field in requests signals whether the user process is performing  
//     a memory read, memory write, or signaling termination.  
//   - The `frame_no` and `is_write` fields in responses communicate the result of  
//     memory access processing.
//
//   Example:
//     - user_proc sends: `{mtype=1, pid=1234, address=0x3AC0, operation=OP_READ}`  
//     - oss responds: `{mtype=1234, frame_no=5, is_write=0}`

#ifndef IPC_H
#define IPC_H

#include <sys/types.h>
#include <stdint.h>

// IPC key configuration for message queue creation via ftok
#define IPC_KEY_FILEPATH    "."     // Path used to generate unique IPC key
#define IPC_KEY_PROJ_ID     'M'     // Project-specific ID for ftok key generation

// Message type constants used for communication
#define MSG_TYPE_REQUEST    1       // All user_proc to oss messages use this type

// Operation codes for memory access or process termination
#define OP_READ         0           // Memory read request
#define OP_WRITE        1           // Memory write request
#define OP_TERMINATE    2           // Indicates process is terminating

// Structure representing a request message sent by user_proc to oss
// All such messages must have mtype set to MSG_TYPE_REQUEST
typedef struct {
    long        mtype;      // Message type (must be > 0); fixed as MSG_TYPE_REQUEST
    pid_t       pid;        // Process ID of the requesting user_proc
    uint32_t    address;    // Memory address being accessed (ignored if terminating)
    int         operation;  // Type of operation: OP_READ, OP_WRITE, or OP_TERMINATE
} request_msg_t;

// Structure representing a response message sent by oss to user_proc
// mtype must be set to the recipient's PID to ensure correct delivery
typedef struct {
    long        mtype;      // Message type = PID of user_proc receiving this message
    int         frame_no;   // Frame number allocated/hit (ignored for termination)
    int         is_write;   // Echoes back OP_READ or OP_WRITE (ignored for termination)
} response_msg_t;

#endif // IPC_H
