// clock.h
// Author: Jerome Ramey, Jr.
// Date: May 15, 2025
// Description:
//   This header defines the interfaces and data structures for the simulated
//   system clock, implemented via SysV shared memory. It allows processes to
//   initialize, attach to, detach from, destroy, increment, and read a shared
//   clock that tracks seconds and nanoseconds.
//
// Usage:
//   - Call init_clock() in the parent to create and initialize the clock.
//   - Fork child processes; they should call attach_clock_segment(shmid) with
//     the shmid returned by init_clock() to attach to the same clock.
//   - All processes can call increment_clock() to advance the clock and
//     get_clock() to read the current time.
//   - Before exiting, processes should call detach_clock().
//   - Finally, the parent should call destroy_clock() to remove the shared
//     memory segment.

#ifndef CLOCK_H
#define CLOCK_H

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdint.h>

/**
 * shm_clock_t
 * ------------
 * Represents the simulated time in shared memory.
 * - sec: seconds component of the clock.
 * - ns:  nanoseconds component of the clock (0 to 999,999,999).
 */
typedef struct {
    uint32_t sec;  // seconds
    uint32_t ns;   // nanoseconds
} shm_clock_t;

/**
 * init_clock
 * -----------
 * Creates or retrieves a SysV shared-memory segment for the simulated clock
 * and attaches the calling process to it. Initializes the clock to 0 seconds
 * and 0 nanoseconds.
 *
 * Return:
 *   On success: the shared-memory segment ID (shmid) for the clock.
 *   On failure: -1 (and perror() is called internally).
 */
int init_clock(void);

/**
 * attach_clock_segment
 * ---------------------
 * Attaches the calling process to an existing shared-memory clock segment.
 * Used by child processes after fork (they inherit the shmid from the parent).
 *
 * @param shmid  The shared-memory segment ID of the clock.
 * @return       0 on success, or -1 on failure (and perror() is called).
 */
int attach_clock_segment(int shmid);

/**
 * detach_clock
 * -------------
 * Detaches the calling process from the shared-memory clock segment.
 * Does not remove the segment itself; other processes may remain attached.
 */
void detach_clock(void);

/**
 * destroy_clock
 * --------------
 * Marks the shared-memory clock segment for removal (IPC_RMID). After this
 * call, no process can reattach to the segment. Typically called by the
 * parent after all children have detached.
 */
void destroy_clock(void);

/**
 * increment_clock
 * ----------------
 * Advances the shared clock by the specified amount of time. Properly handles
 * nanosecond overflow by carrying into the seconds field.
 *
 * @param sec  Number of seconds to add.
 * @param ns   Number of nanoseconds to add.
 */
void increment_clock(uint32_t sec, uint32_t ns);

/**
 * get_clock
 * ----------
 * Retrieves the current value of the shared clock.
 *
 * @param sec  Pointer to store the seconds component (must be non-NULL).
 * @param ns   Pointer to store the nanoseconds component (must be non-NULL).
 *
 * If the clock is not attached or any pointer is NULL, the function returns
 * without modifying the outputs.
 */
void get_clock(uint32_t *sec, uint32_t *ns);

#endif // CLOCK_H
