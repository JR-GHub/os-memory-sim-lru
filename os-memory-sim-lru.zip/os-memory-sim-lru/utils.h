// utils.h
// Author: Jerome Ramey, Jr.
// Date: May 15, 2025
//
// Description:
//   Header file for utility functions used in the CS4760 Project 6 virtual memory simulation.
//   Declares support routines for logging, random memory behavior generation,
//   and formatted printing of system memory structures including frame and page tables.
//
// Usage:
//   Include this header in both the OSS and user_proc source files.
//   Before using logging or generation functions, initialize them with init_logging() and init_random().
//   After simulation ends, call close_logging() to properly flush and release the log file.

#ifndef UTILS_H
#define UTILS_H

#include <stdint.h>
#include "oss.h"
#include "ipc.h"

/**
 * init_logging
 * ------------
 * Opens the given file path for writing simulation logs.
 * Overwrites existing contents. This must be called before any use of log_event().
 *
 * @param filename  Full or relative path to log file.
 */
void init_logging(const char *filename);

/**
 * close_logging
 * -------------
 * Closes the currently open log file if logging was initialized.
 * Safe to call multiple times; does nothing if already closed.
 */
void close_logging(void);

/**
 * init_random
 * -----------
 * Seeds the pseudo-random number generator using the current time XOR the process ID.
 * Ensures each process (especially forked ones) produces unique memory access patterns.
 */
void init_random(void);

/**
 * generate_address
 * ----------------
 * Produces a random simulated memory address within the 32KB virtual address space.
 * Computes: random_page * PAGE_SIZE + random_offset
 * where PAGE_SIZE is 1024 bytes and PAGE_TABLE_SIZE is 32.
 *
 * @return  A 32-bit memory address as an unsigned integer.
 */
uint32_t generate_address(void);

/**
 * generate_operation
 * ------------------
 * Simulates read/write access behavior by returning:
 *   - OP_READ with 80% probability
 *   - OP_WRITE with 20% probability
 *
 * @return  OP_READ or OP_WRITE based on weighted random selection.
 */
int generate_operation(void);

/**
 * log_event
 * ---------
 * Outputs a formatted message to both the open log file and stdout.
 * Accepts printf-style formatting with variable arguments.
 * Automatically appends newline and flushes both outputs.
 *
 * @param fmt   Format string (like printf).
 * @param ...   Variable argument list for format specifiers.
 */
void log_event(const char *fmt, ...);

/**
 * print_frame_table
 * -----------------
 * Logs a formatted table of all physical memory frames.
 * For each frame, shows whether it's occupied, if it's dirty,
 * which process owns it, which page is loaded, and its last use time.
 *
 * @param frames  Array of frame_t entries representing physical memory.
 * @param size    Number of entries (typically FRAME_TABLE_SIZE = 256).
 */
void print_frame_table(frame_t frames[], int size);

/**
 * print_page_tables
 * -----------------
 * Iterates through the PCB table and prints each active process’s page table.
 * Each page table shows the mapping from virtual page index to frame number.
 * A value of -1 indicates the page is not currently loaded.
 *
 * @param pcbs        Array of pcb_t process entries.
 * @param max_procs   Number of entries in the PCB table (usually MAX_PROCS).
 */
void print_page_tables(pcb_t pcbs[], int max_procs);

#endif // UTILS_H
