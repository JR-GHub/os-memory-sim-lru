// page_table.c
// Author: Jerome Ramey, Jr.
// Date: May 15, 2025
// Description:
//   This module implements per-process page table operations for the CS4760
//   Project 6 Operating System Simulator. It provides functions to initialize,
//   query, update, invalidate, and clear virtual-to-physical page mappings.
//   Each process maintains a fixed-size page table of PAGE_TABLE_SIZE entries,
//   where each entry holds the physical frame number or -1 if the page is not loaded.
//
// Usage:
//   1. Include "page_table.h" in source files that need to manipulate page tables.
//   2. Call init_page_table() once per process PCB before simulation begins.
//   3. Use get_frame_for_page() to check whether a virtual page is resident
//      (returns frame number or -1 if not resident).
//   4. Use set_page_frame() when loading a page into memory to record the
//      frame assignment in the page table.
//   5. Use invalidate_page() to unmap a single page (e.g., when evicting
//      or on process termination).
//   6. Use clear_page_table() to reset all entries to -1 (e.g., on process
//      reset or recycle).
//   7. All functions perform bounds checking on page_num to prevent invalid access.
//
// Example:
//     pcb_t pcb;
//     init_page_table(pcb.page_table);
//     int frame = find_free_frame();                     // from frame_table.c
//     set_page_frame(pcb.page_table, 5, frame);          // map virtual page 5 → frame
//     int loaded_frame = get_frame_for_page(pcb.page_table, 5);
//     if (loaded_frame >= 0) { /* hit */ } else { /* fault */ }
//     invalidate_page(pcb.page_table, 5);                // unmap page 5
//     clear_page_table(pcb.page_table);                  // reset all mappings
//
//-----------------------------------------------------------------------------

#include "page_table.h"
#include <string.h>

/**
 * init_page_table
 * ----------------
 * Initialize a page table by marking all entries as not loaded.
 *
 * @param page_table  Array of PAGE_TABLE_SIZE entries to initialize.
 */
void init_page_table(int page_table[]) {
    for (int i = 0; i < PAGE_TABLE_SIZE; ++i) {
        page_table[i] = -1;   // -1 indicates page is not resident in any frame
    }
}

/**
 * get_frame_for_page
 * ------------------
 * Retrieve the frame number assigned to a given virtual page in the table.
 *
 * @param page_table  The page table array.
 * @param page_num    The virtual page number to look up.
 * @return            The frame number if loaded, or -1 if not loaded or invalid page_num.
 */
int get_frame_for_page(int page_table[], int page_num) {
    if (page_num < 0 || page_num >= PAGE_TABLE_SIZE) {
        return -1;           // Out-of-bounds page numbers are invalid
    }
    return page_table[page_num];
}

/**
 * set_page_frame
 * --------------
 * Map a virtual page to a specific physical frame. Overwrites any existing mapping.
 *
 * @param page_table  The page table array.
 * @param page_num    The virtual page number to set (0 ≤ page_num < PAGE_TABLE_SIZE).
 * @param frame_no    The physical frame number to assign.
 */
void set_page_frame(int page_table[], int page_num, int frame_no) {
    if (page_num < 0 || page_num >= PAGE_TABLE_SIZE) {
        return;             // Skip invalid page indices
    }
    page_table[page_num] = frame_no;
}

/**
 * invalidate_page
 * ---------------
 * Unmap (invalidate) a single virtual page, marking it as not resident.
 *
 * @param page_table  The page table array.
 * @param page_num    The virtual page number to invalidate.
 */
void invalidate_page(int page_table[], int page_num) {
    if (page_num < 0 || page_num >= PAGE_TABLE_SIZE) {
        return;             // Skip invalid page indices
    }
    page_table[page_num] = -1;
}

/**
 * clear_page_table
 * ----------------
 * Reset an entire page table by invalidating all entries. Equivalent to init_page_table.
 *
 * @param page_table  The page table array to clear.
 */
void clear_page_table(int page_table[]) {
    init_page_table(page_table);
}
