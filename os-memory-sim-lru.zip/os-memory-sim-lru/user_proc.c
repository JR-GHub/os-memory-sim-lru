// user_proc.c
// Author: Jerome Ramey, Jr.
// Date: May 15, 2025
//
// Description:
//   This module implements the user process component of the CS4760 Project 6
//   virtual memory simulator. Each user_proc generates a stream of simulated
//   memory read/write requests, sends them to the Operating System Simulator (OSS)
//   via a SysV message queue, and awaits responses indicating page hits or frame
//   assignments. After a randomized number of memory accesses, the process informs
//   OSS that it is terminating and then exits cleanly.
//
// Usage:
//   1. Compile both OSS and user_proc using the provided Makefile: `make`
//   2. Launch OSS, specifying total processes (-n), max concurrent (-s),
//      spawn interval in ms (-i), and log file path (-f):
//        ./oss -n 50 -s 10 -i 5 -f oss.log
//   3. OSS will fork user_proc instances automatically. Do not invoke user_proc
//      directly; it expects to be managed by OSS.
//   4. Each user_proc attaches to the shared clock, sends memory requests until
//      it reaches its random threshold (900–1100 accesses), then sends a termination
//      message and detaches before exiting.
//
// IPC Protocol:
//   - All outgoing messages to OSS use mtype = MSG_TYPE_REQUEST.
//   - Request payload includes PID (for OSS routing), a 32-bit address, and an
//     operation code (OP_READ, OP_WRITE, OP_TERMINATE).
//   - Incoming responses from OSS use mtype = this process’s PID, carrying the
//     allocated frame number and echoed operation code.
//
// Exit Conditions:
//   - After sending the OP_TERMINATE request, the process breaks out of its loop,
//     detaches from the shared clock, and returns 0.
//   - Any IPC error (ftok, msgget, msgsnd, msgrcv) results in perror() and exit.
//
//----------------------------------------------------------------------------- 

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include "ipc.h"
#include "utils.h"
#include "clock.h"

int main(void) {
    // ------------------------------------------------------------------------
    // 1) Attach to the shared simulated clock.
    //    init_clock() uses ftok/shmget/shmat under the hood; returns -1 on failure.
    // ------------------------------------------------------------------------
    if (init_clock() == -1) {
        // If initialization fails, there is no shared clock to coordinate with OSS.
        exit(EXIT_FAILURE);
    }

    // ------------------------------------------------------------------------
    // 2) Seed the pseudo-random number generator uniquely per process.
    //    Ensures diverse address and operation patterns.
    // ------------------------------------------------------------------------
    init_random();

    // ------------------------------------------------------------------------
    // 3) Obtain the message queue key and ID for IPC with OSS.
    //    - ftok constructs a unique key using IPC_KEY_FILEPATH and IPC_KEY_PROJ_ID.
    //    - msgget retrieves the existing queue; permissions are read/write.
    // ------------------------------------------------------------------------
    key_t key = ftok(IPC_KEY_FILEPATH, IPC_KEY_PROJ_ID);
    if (key == -1) {
        perror("ftok");   // Failed to generate IPC key
        exit(EXIT_FAILURE);
    }

    int msqid = msgget(key, 0666);
    if (msqid == -1) {
        perror("msgget"); // Failed to access message queue
        exit(EXIT_FAILURE);
    }

    // ------------------------------------------------------------------------
    // 4) Prepare local state for request loop.
    //    - pid: used to direct OSS responses back to this process.
    //    - access_count: counts number of memory operations sent.
    //    - term_threshold: random cutoff to decide when to terminate.
    // ------------------------------------------------------------------------
    pid_t pid = getpid();
    int access_count = 0;
    // Random threshold: uniform in [900,1100]
    int term_threshold = 1000 + (rand() % 201) - 100;

    // ------------------------------------------------------------------------
    // 5) Main loop: generate/send requests until reaching term_threshold.
    // ------------------------------------------------------------------------
    while (1) {
        // --------------------------------------------------------------------
        // 5a) Check if we've reached or exceeded our random termination count.
        //     If so, send an OP_TERMINATE request and break out of the loop.
        // --------------------------------------------------------------------
        if (access_count >= term_threshold) {
            request_msg_t term_msg = {
                .mtype     = MSG_TYPE_REQUEST,
                .pid       = pid,            // Let OSS know which process
                .address   = 0,              // Ignored by OSS on termination
                .operation = OP_TERMINATE    // Signal termination
            };
            if (msgsnd(msqid, &term_msg, sizeof(term_msg) - sizeof(long), 0) == -1) {
                perror("msgsnd terminate");
            }
            break;
        }

        // --------------------------------------------------------------------
        // 5b) Generate a random memory access:
        //     - addr: 32-bit address = page * PAGE_SIZE + offset
        //     - op:   OP_READ or OP_WRITE (80% reads, 20% writes)
        // --------------------------------------------------------------------
        uint32_t addr = generate_address();
        int op = generate_operation();

        // --------------------------------------------------------------------
        // 5c) Package and send the memory request to OSS.
        //     Blocking on error: if send fails, exit the loop and terminate.
        // --------------------------------------------------------------------
        request_msg_t req = {
            .mtype     = MSG_TYPE_REQUEST,
            .pid       = pid,
            .address   = addr,
            .operation = op
        };
        if (msgsnd(msqid, &req, sizeof(req) - sizeof(long), 0) == -1) {
            perror("msgsnd request");
            break;
        }

        // --------------------------------------------------------------------
        // 5d) Wait (block) for OSS to respond with the frame number or hit info.
        //     Filter messages by mtype == pid ensures we receive our own responses.
        // --------------------------------------------------------------------
        response_msg_t resp;
        if (msgrcv(msqid, &resp, sizeof(resp) - sizeof(long), pid, 0) == -1) {
            perror("msgrcv response");
            break;
        }

        // --------------------------------------------------------------------
        // 5e) On successful response, increment our local access counter.
        // --------------------------------------------------------------------
        access_count++;
    }

    // ------------------------------------------------------------------------
    // 6) Detach from the shared clock and exit cleanly.
    // ------------------------------------------------------------------------
    detach_clock();
    return 0;
}
