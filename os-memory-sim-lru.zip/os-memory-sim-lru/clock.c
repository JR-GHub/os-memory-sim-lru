// clock.c
// Author: Jerome Ramey, Jr.
// Date: May 15, 2025
// Description:
//   This module implements a simulated system clock using SysV shared memory.
//   It provides functions to initialize, attach, detach, destroy, increment,
//   and retrieve the clock values. The clock consists of seconds and
//   nanoseconds fields and is shared among multiple processes to simulate
//   the passage of time in the operating system simulator.
//
// Usage:
//   - The parent (oss) process should call init_clock() to create and attach
//     to a shared-memory clock segment. This will initialize the simulated
//     clock to 0 seconds and 0 nanoseconds.
//   - Any child or external process should call attach_clock_segment(shmid)
//     with the shared memory ID to join the same simulated clock segment.
//   - Use increment_clock(sec, ns) to advance the clock by a specific duration.
//   - Use get_clock(&sec, &ns) to retrieve the current simulated clock value.
//   - When a process is done with the clock, call detach_clock() to detach
//     from the shared segment.
//   - When the simulation ends, the parent process should call destroy_clock()
//     to remove the shared-memory clock segment completely.

#include "clock.h"
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>

// Forward declaration for attaching to an existing clock segment.
// Defined later in this file. Used internally when another process
// needs to attach to the same shared-memory region.
int attach_clock_segment(int shmid);

// Pointer to the shared-memory clock structure.
// After shmat, this points to a shm_clock_t in shared memory.
static shm_clock_t *clock_ptr = NULL;

// Shared-memory segment ID for the clock.
// Set by init_clock() or attach_clock_segment().
// Used for cleanup (IPC_RMID) in destroy_clock().
static int clock_shmid = -1;

/**
 * init_clock
 * ----------
 * Initializes the simulated system clock using System V shared memory.
 * This function should be called by the master process (e.g., oss) at startup
 * to create a shared clock segment accessible by child processes.
 *
 * Steps:
 *   1. Uses `ftok` to generate a unique key based on the current directory
 *      and a project-specific identifier ('C'). This key ensures that all
 *      processes refer to the same shared-memory segment.
 *   2. Calls `shmget` to create or retrieve a shared-memory segment of
 *      sufficient size to hold a `shm_clock_t` structure, with full read/write
 *      permissions (0666) and the IPC_CREAT flag to create it if it doesn't exist.
 *   3. Calls `shmat` to attach the created segment to the process’s address space
 *      so that the process can read and modify the simulated clock.
 *
 * If any of these steps fail, the function logs the error using `perror()` and
 * returns -1 to indicate failure. On success, it initializes the global `clock_ptr`
 * and `clock_shmid`, and the calling process can begin manipulating the clock.
 *
 * @return Shared-memory ID (shmid) on success, or -1 on failure.
 */
int init_clock(void) {
    // Generate a unique key for the shared memory segment using current directory and project ID
    key_t key = ftok(".", 'C');
    if (key == -1) {
        // Failed to generate IPC key; log and return failure
        perror("ftok");
        return -1;
    }

    // Allocate or retrieve a shared memory segment large enough for the clock struct
    clock_shmid = shmget(key, sizeof(shm_clock_t), IPC_CREAT | 0666);
    if (clock_shmid == -1) {
        // Failed to create/get shared memory segment; log and return failure
        perror("shmget");
        return -1;
    }

    // Attach the shared memory segment to the process's address space
    clock_ptr = (shm_clock_t *)shmat(clock_shmid, NULL, 0);
    if (clock_ptr == (void *)-1) {
        // Failed to attach; reset pointer and return failure
        perror("shmat");
        clock_ptr = NULL;
        return -1;
    }

    // Initialize the shared clock fields to zero
    clock_ptr->sec = 0;
    clock_ptr->ns  = 0;

    return clock_shmid;
}

/**
 * detach_clock
 * -------------
 * Detaches this process from the shared-memory clock segment.
 * Does not remove the segment itself; other processes may still be attached.
 *
 * If this process is not currently attached, does nothing.
 */
void detach_clock(void) {
    if (clock_ptr != NULL) {
        shmdt(clock_ptr);
        clock_ptr = NULL;
    }
}

/**
 * destroy_clock
 * -------------
 * Marks the shared-memory segment for removal.
 * After this call, no process can reattach to the same segment.
 *
 * If the segment has already been removed or never created, does nothing.
 */
void destroy_clock(void) {
    if (clock_shmid != -1) {
        shmctl(clock_shmid, IPC_RMID, NULL);
        clock_shmid = -1;
    }
}

/**
 * attach_clock_segment
 * ---------------------
 * Attaches this process to an existing shared-memory segment for the clock.
 * Intended for child processes that inherit the shmid from the parent.
 *
 * @param shmid  The shared-memory ID of the existing clock segment.
 * @return       0 on success, -1 on failure.
 *
 * On success, sets clock_shmid and clock_ptr to point to the shared region.
 * On failure, prints an error and leaves clock_ptr as NULL.
 */
int attach_clock_segment(int shmid) {
    clock_shmid = shmid;
    clock_ptr = (shm_clock_t *)shmat(shmid, NULL, 0);
    if (clock_ptr == (void *)-1) {
        perror("shmat attach");
        clock_ptr = NULL;
        return -1;
    }
    return 0;
}

/**
 * increment_clock
 * ----------------
 * Advances the simulated clock by the specified amount of time.
 * Handles the carry of nanoseconds into seconds when the nanosecond
 * field would overflow.
 *
 * @param sec  Number of seconds to add.
 * @param ns   Number of nanoseconds to add.
 *
 * If clock_ptr is NULL (not attached), the function returns immediately.
 */
void increment_clock(uint32_t sec, uint32_t ns) {
    if (clock_ptr == NULL) {
        // No clock attached; nothing to increment.
        return;
    }

    // Calculate total nanoseconds and derive carry seconds
    uint64_t total_ns = (uint64_t)clock_ptr->ns + ns;
    uint32_t carry_sec = total_ns / 1000000000u;
    uint32_t rem_ns   = total_ns % 1000000000u;

    // Update shared clock fields atomically (assumes single writer)
    clock_ptr->sec += sec + carry_sec;
    clock_ptr->ns   = rem_ns;
}

/**
 * get_clock
 * ----------
 * Retrieves the current value of the simulated clock.
 *
 * @param sec  Pointer to store the seconds component.
 * @param ns   Pointer to store the nanoseconds component.
 *
 * If any pointer is NULL or clock_ptr is not attached, the function
 * returns without modifying the outputs.
 */
void get_clock(uint32_t *sec, uint32_t *ns) {
    if (clock_ptr == NULL || sec == NULL || ns == NULL) {
        // Invalid pointers or no clock attached; skip retrieval.
        return;
    }

    *sec = clock_ptr->sec;
    *ns  = clock_ptr->ns;
}

