// frame_table.c
// Author: Jerome Ramey, Jr.
// Date: May 15, 2025
//
// Description:
//   This module implements all functionality related to managing the frame table in the
//   CS4760 Project 6 virtual memory simulation. Each frame represents a fixed-size block of
//   physical memory that may hold a virtual page of a user process. This file provides
//   logic for initializing the frame table, locating free frames, selecting a frame for
//   eviction based on Least Recently Used (LRU) policy, updating access metadata for frames,
//   and cleaning up frames when a process terminates.
//
// Usage:
//   The `frame_t` structure defined in `oss.h` is used to represent each frame.
//   These functions should be used by OSS (Operating System Simulator) to manage memory:
//
//   - Call `init_frame_table()` once at the start of the simulation to initialize the table.
//   - Whenever a page needs to be loaded, call `find_free_frame()`.
//     If no frame is free, fall back to `select_lru_frame()` for eviction.
//   - Call `update_frame_reference()` every time a memory access hits a frame to update
//     its last used time (and dirty bit if written).
//   - Use `clear_frame()` when a page is evicted or no longer used.
//   - Use `free_frames_by_pid()` when a process terminates to free its memory.

#include "frame_table.h"
#include "clock.h"
#include <stdint.h>
#include <limits.h>

/**
 * init_frame_table
 * ----------------
 * Initializes every frame in the frame table by resetting its metadata to default.
 * Marks each frame as unoccupied and clears all reference timestamps and ownership.
 *
 * @param frames Array of frame_t structs representing the physical memory.
 */
void init_frame_table(frame_t frames[]) {
    for (int i = 0; i < FRAME_TABLE_SIZE; ++i) {
        frames[i].occupied = false;
        frames[i].dirty = false;
        frames[i].pid = -1;
        frames[i].page_number = -1;
        frames[i].last_ref_sec = 0;
        frames[i].last_ref_ns = 0;
    }
}

/**
 * find_free_frame
 * ---------------
 * Scans the frame table for the first unoccupied frame.
 * Useful when allocating memory for a new page without replacement.
 *
 * @param frames Frame table array to scan.
 * @return Index of the first available frame; -1 if none are free.
 */
int find_free_frame(frame_t frames[]) {
    for (int i = 0; i < FRAME_TABLE_SIZE; ++i) {
        if (!frames[i].occupied) {
            return i;
        }
    }
    return -1;
}

/**
 * select_lru_frame
 * ----------------
 * Selects the Least Recently Used frame by comparing last referenced timestamps.
 * Used as a page replacement policy when no free frames are available.
 *
 * @param frames Frame table array.
 * @return Index of the LRU frame; -1 if no frames are occupied.
 */
int select_lru_frame(frame_t frames[]) {
    int lru_index = -1;
    uint32_t min_sec = UINT32_MAX;
    uint32_t min_ns = UINT32_MAX;

    for (int i = 0; i < FRAME_TABLE_SIZE; ++i) {
        if (frames[i].occupied) {
            uint32_t sec = frames[i].last_ref_sec;
            uint32_t ns = frames[i].last_ref_ns;
            if (sec < min_sec || (sec == min_sec && ns < min_ns)) {
                min_sec = sec;
                min_ns = ns;
                lru_index = i;
            }
        }
    }
    return lru_index;
}

/**
 * update_frame_reference
 * ----------------------
 * Updates the metadata of a frame to reflect a recent memory access.
 * This includes setting the last accessed time using the simulated clock,
 * and optionally marking the frame dirty if the operation was a write.
 *
 * @param frames    Frame table array.
 * @param frame_no  Index of the frame to update.
 * @param is_write  True if access was a write operation; false for reads.
 */
void update_frame_reference(frame_t frames[], int frame_no, bool is_write) {
    uint32_t sec, ns;
    get_clock(&sec, &ns);

    frames[frame_no].last_ref_sec = sec;
    frames[frame_no].last_ref_ns = ns;

    if (is_write) {
        frames[frame_no].dirty = true;
    }
}

/**
 * clear_frame
 * -----------
 * Resets a frame's metadata, making it available for future page allocations.
 * Typically used after a page is evicted or invalidated.
 *
 * @param frames    Frame table array.
 * @param frame_no  Index of the frame to clear.
 */
void clear_frame(frame_t frames[], int frame_no) {
    frames[frame_no].occupied = false;
    frames[frame_no].dirty = false;
    frames[frame_no].pid = -1;
    frames[frame_no].page_number = -1;
    frames[frame_no].last_ref_sec = 0;
    frames[frame_no].last_ref_ns = 0;
}

/**
 * free_frames_by_pid
 * ------------------
 * Frees all frames currently owned by the specified process.
 * Called when a process terminates, allowing its pages to be reused by others.
 *
 * @param frames Frame table array.
 * @param pid    Process ID whose frames should be reclaimed.
 */
void free_frames_by_pid(frame_t frames[], pid_t pid) {
    for (int i = 0; i < FRAME_TABLE_SIZE; ++i) {
        if (frames[i].occupied && frames[i].pid == pid) {
            clear_frame(frames, i);
        }
    }
}
