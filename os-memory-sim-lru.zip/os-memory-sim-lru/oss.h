// oss.h
// Author: Jerome Ramey, Jr.
// Date: May 15, 2025
// Description:
//   Header for the Operating System Simulator (OSS) in CS4760 Project 6.
//   Defines global constants, timing parameters, and core data structures
//   used across the simulator, including Process Control Blocks (PCBs)
//   and Frame Table Entries. These definitions underpin virtual memory
//   management, page replacement, and simulation timing across OSS and
//   user processes.
//
// Usage:
//   1. Include this header in source files that manipulate PCBs, frames,
//      or require system-wide constants (e.g., oss.c, frame_table.c,
//      page_table.c, user_proc.c).
//   2. Ensure that PAGE_SIZE, PAGE_TABLE_SIZE, and FRAME_TABLE_SIZE
//      match across all modules to maintain consistent memory models.
//   3. Adjust MEM_ACCESS_TIME_NS, CLEAN_SWAP_TIME_NS, and
//      DIRTY_SWAP_TIME_NS to tune simulated latency for hits and swaps.
//   4. MAX_PROCS and MAX_TOTAL_PROCS control concurrency and overall
//      workload; these limits safeguard against resource exhaustion.
//   5. PCB.page_table entries map virtual pages to physical frames;
//      initialize to –1 for unloaded pages. Frame entries track LRU
//      timestamps for replacement decisions.
//
//   Example:
//     pcb_t process_table[MAX_PROCS];
//     frame_t frame_table[FRAME_TABLE_SIZE];
//     // Initialize all PCBs and frames before simulation.
//     for (int i = 0; i < MAX_PROCS; i++) {
//         process_table[i].occupied = false;
//         memset(process_table[i].page_table, -1, sizeof(process_table[i].page_table));
//     }
//     for (int i = 0; i < FRAME_TABLE_SIZE; i++) {
//         frame_table[i].occupied = false;
//     }
//
//   Use MEM_ACCESS_TIME_NS when simulating each memory reference,
//   and use CLEAN_SWAP_TIME_NS or DIRTY_SWAP_TIME_NS when enqueuing
//   page-in requests based on the dirty bit.
//
//-----------------------------------------------------------------------------

#ifndef OSS_H
#define OSS_H

#include <sys/types.h>
#include <stdint.h>
#include <stdbool.h>

// ---------------------------------------------------------------------------
// System-wide memory model parameters
// ---------------------------------------------------------------------------

#define PAGE_SIZE             1024       // Size of one virtual memory page in bytes
#define PAGE_TABLE_SIZE       32         // Number of pages per process (32 KB addressable)
#define FRAME_TABLE_SIZE      256        // Number of physical frames (128 KB total)
#define MAX_PROCS             18         // Max concurrent user processes in simulation
#define MAX_TOTAL_PROCS       100        // Upper limit on total processes spawned over run

// ---------------------------------------------------------------------------
// Timing constants for simulated latency (in nanoseconds)
// ---------------------------------------------------------------------------

#define MEM_ACCESS_TIME_NS    100UL      // Time to service a memory hit (read/write) 
#define CLEAN_SWAP_TIME_NS    10000000UL // Clean page-in time (~10 ms)
#define DIRTY_SWAP_TIME_NS    14000000UL // Dirty page-in time with write-back (~14 ms)

// ---------------------------------------------------------------------------
// Process Control Block (PCB)
// ---------------------------------------------------------------------------
// Represents a single user process in the simulator. Each PCB slot holds:
//   - occupied:    whether the slot is in use by an active process
//   - pid:         the OS-assigned PID of the forked child
//   - start_sec:   simulated clock seconds when process was spawned
//   - start_ns:    simulated clock nanoseconds when process was spawned
//   - page_table:  mapping from virtual page index [0..PAGE_TABLE_SIZE-1]
//                  to physical frame index [0..FRAME_TABLE_SIZE-1], or -1
//                  if the page is not currently loaded.
//
// Initialize `occupied = false` and each `page_table[i] = -1` before starting.
//
typedef struct pcb {
    bool        occupied;                        // PCB slot in use?
    pid_t       pid;                             // Child process ID
    uint32_t    start_sec;                       // Spawn time: seconds
    uint32_t    start_ns;                        // Spawn time: nanoseconds
    int         page_table[PAGE_TABLE_SIZE];     // Virtual→physical mapping (-1 = unloaded)
} pcb_t;

// ---------------------------------------------------------------------------
// Frame Table Entry
// ---------------------------------------------------------------------------
// Represents one frame in physical memory. Each entry holds:
//   - occupied:     whether a page currently occupies this frame
//   - dirty:        whether the page has been written since loaded
//   - pid:          process ID of the owner of this frame
//   - page_number:  virtual page index resident in this frame
//   - last_ref_sec: simulated seconds of last access (for LRU algorithm)
//   - last_ref_ns:  simulated nanoseconds of last access
//
// On eviction, clear `occupied` and reset other fields as needed. Use
// last_ref_sec/ns to compare frames for LRU selection.
//
typedef struct frame_entry {
    bool        occupied;        // Frame allocated?
    bool        dirty;           // Dirty bit (true if written)
    pid_t       pid;             // Owner process ID
    int         page_number;     // Loaded virtual page number
    uint32_t    last_ref_sec;    // LRU: last access seconds
    uint32_t    last_ref_ns;     // LRU: last access nanoseconds
} frame_t;

#endif // OSS_H
